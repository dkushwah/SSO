﻿namespace DkSSO.Core
{
	public static class AdConstants
	{
		public static string ApplicationTool = "ldap";
	}
}
