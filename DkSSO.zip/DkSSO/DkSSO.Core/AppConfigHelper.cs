﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DkSSO.Core
{
    /// <summary>
    /// 
    /// </summary>
    public static class AppConfigHelper
    {
        /// <summary>
        /// 
        /// </summary>
        public static string[] RelyingParties
        {
            get
            {
                var rp = ConfigurationManager.AppSettings[AppConstants.RelyingParty];
                return rp != null ? rp.Split(',') : null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static string SsoProviderAddress
        {
            get { return ConfigurationManager.AppSettings[AppConstants.SsoProvider]; }
        }
        /// <summary>
        /// 
        /// </summary>
        public static string AdPath
        {
            get { return ConfigurationManager.AppSettings[AppConstants.LDapServerDomain]; }
        }
        /// <summary>
        /// 
        /// </summary>
        public static string LdapServerDirectory
        {
            get { return ConfigurationManager.AppSettings[AppConstants.LDapServerDirectoryPath]; }
        }
    }
}
