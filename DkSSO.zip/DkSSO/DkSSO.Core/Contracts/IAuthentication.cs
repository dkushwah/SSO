﻿using System.ServiceModel;

namespace DkSSO.Core.Contracts
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceContract]
    public interface IAuthentication
    {
        [OperationContract]
        string RequestToken(string username, string password);
    }
}
