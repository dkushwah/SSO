﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DkSSO.Core.Exception
{
    /// <summary>
    /// 
    /// </summary>
    public class RelyingPartyNotFound : System.Exception
    {
        public RelyingPartyNotFound() : base()
        {

        }

        public RelyingPartyNotFound(string message)
            : base(message)
        {

        }

    }
}
