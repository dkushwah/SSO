﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DkSSO.AuthenticationService;
using DkSSO.Core;
using DkSSO.Core.Manager;
using DkSSO.Core.Utility;
using DkSSO.Models;

namespace DkSSO.Controllers
{
    /// <summary>
    /// Authentication controller for login page
    /// </summary>
    public class AuthController : Controller
    {
        private readonly AuthenticationClient _authenticationClient;
        private readonly RelyingPartyManager _relyingPartyManager;
        public AuthController()
        {
            _relyingPartyManager = new RelyingPartyManager();
            _authenticationClient = new AuthenticationClient("BasicHttpBinding_IAuthentication");
        }

        [HttpGet]
        public ActionResult Login()
        {
            var returnurl = string.Empty;
            if (Request.Url != null)
            {
                returnurl= Request.QueryString.Get(AppConstants.ReturnUrl);
            }
            _relyingPartyManager.ValidateRelyingParty(returnurl);
            var login = new LogInViewModel()
            {
                UserName = "euclid",
                Password = "password",
                ReturnUrl = returnurl
            };
            return View(login);
        }

        [HttpPost]
        public ActionResult Login(LogInViewModel logInViewModel)
        {
            if (!ModelState.IsValid) return View();
            var tokendata = _authenticationClient.RequestToken(logInViewModel.UserName, logInViewModel.Password);
            if (string.IsNullOrEmpty(logInViewModel.ReturnUrl)) return View();
            var returnurl = string.Format("{0}?token={1}", logInViewModel.ReturnUrl, tokendata);
            Response.Redirect(returnurl);
            return View();
        }

    }
}