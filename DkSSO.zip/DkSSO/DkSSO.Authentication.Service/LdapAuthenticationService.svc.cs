﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Security.Claims;
using DkSSO.Core;
using DkSSO.Core.Contracts;
using DkSSO.Core.Security;


namespace DkSSO.Service.Host
{
    public class LdapAuthenticationService : IAuthentication
    {
        private string DomainName = AppConfigHelper.AdPath;
        private string UserName = String.Empty;
        private string Password = String.Empty;
        private string GroupName = String.Empty;

        private const string SamAccountName = "samaccountname=";
        private const string DisplayName = "cn";
        private const string UserAccountControl = "useraccountcontrol";

        private const int InvalidDomainPath = -2147467259;
        private const int NotOperational = -2147016646;
        private const int Unknown = -2147463168;


        /// <summary>
        /// To validate Login User in Ad 
        /// </summary>
        /// <param name="domainName"></param>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public ADError ValidateUser(string domainName, string userName, string password)
        {
            domainName = AppConfigHelper.AdPath;
            ADError err = ADError.AD_Success;

            this.DomainName = domainName;
            this.UserName = userName;
            this.Password = password;

            //Validate Input Parameters
            if ((err = ValidateParams()) != ADError.AD_Success)
                return err;

            //Get AD Directory Entry
            if ((err = ValidateInAD()) != ADError.AD_Success)
                return err;

            return err;
        }

        private ADError ValidateParams()
        {
            ADError err = ADError.AD_Success;

            if (DomainName == null || UserName == null || Password == null)
                return ADError.AD_InvalidParams;

            if (DomainName == String.Empty || UserName == String.Empty || Password == String.Empty)
                return ADError.AD_InvalidParams;

            return err;
        }

        private ADError ValidateInAD()
        {
            ADError err = ADError.AD_Success;
            DirectoryEntry directoryEntry = null;// new DirectoryEntry(DomainName, UserName, Password);
            DirectorySearcher directorySearcher = null;// new DirectorySearcher(directoryEntry);
            try
            {
                directoryEntry = new DirectoryEntry(DomainName, UserName, Password);
                directorySearcher = new DirectorySearcher(directoryEntry);
                if (true)
                {

                    directorySearcher.Filter = SamAccountName + UserName;
                    directorySearcher.PropertiesToLoad.Add(DisplayName);
                    directorySearcher.PropertiesToLoad.Add(UserAccountControl);
                    SearchResult searchResult = directorySearcher.FindOne();
                    if (searchResult == null)
                    {
                        err = ADError.AD_InvalidCredentials;
                    }
                    else
                    {
                        if (!IsActive(searchResult))
                        {
                            err = ADError.AD_InvalidCredentials;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.HResult == NotOperational || ex.HResult == Unknown)
                    err = ADError.AD_NotOperational;
                else if (ex.HResult == InvalidDomainPath)
                    err = ADError.AD_InvalidDomainPath;
                else
                    err = ADError.AD_InvalidCredentials;
            }
            finally
            {
                if (directorySearcher != null)
                {
                    directorySearcher.Dispose();
                }
                if (directoryEntry != null)
                {
                    directoryEntry.Close();
                    directoryEntry.Dispose();
                }
            }
            return err;
        }

        private bool IsActive(SearchResult searchResult)
        {
            if (searchResult.Properties["userAccountControl"].Count > 0)
            {
                int flags = (int)searchResult.Properties["userAccountControl"][0];
                return !Convert.ToBoolean(flags & 0x0002);
            }
            return false;
        }
        /// <summary>
        /// Method to Check the User belongs to AAM Group.
        /// </summary>
        /// <param name="domainName"></param>
        /// <param name="userName"></param>
        /// <param name="applicationName"></param>
        /// <returns></returns>
        public bool ValidatepGroupUser(string userName, string applicationName)
        {
            #region object Declaration
            ADError err = ADError.AD_Success;


            DomainName = AppConfigHelper.AdPath;
            var ctx = new PrincipalContext(ContextType.Domain, DomainName);
            var user = UserPrincipal.FindByIdentity(ctx, userName);
            bool vallidateUserGroup = false;
            #endregion object Declaration

            try
            {
                GroupName = ConfigurationManager.AppSettings["ADGroupName"];

                if (applicationName.Trim().ToLower() == AdConstants.ApplicationTool)
                {
                    GroupPrincipal group = GroupPrincipal.FindByIdentity(ctx, GroupName);


                    if (user != null)
                    {
                        // check if user is member of that group
                        if (user.IsMemberOf(group))
                        {
                            err = ADError.AD_Success;
                            vallidateUserGroup = true;
                        }
                        else
                        {
                            err = ADError.AD_InvalidMemberInGroup;
                        }
                    }
                    else
                    {
                        err = ADError.AD_InvalidCredentials;
                    }
                }
                else
                {
                    err = ADError.AD_NotOperational;
                }
            }
            catch (Exception ex)
            {
                if (ex.HResult == NotOperational || ex.HResult == Unknown)
                    err = ADError.AD_NotOperational;
                else if (ex.HResult == InvalidDomainPath)
                    err = ADError.AD_InvalidDomainPath;
                else
                    err = ADError.AD_InvalidCredentials;
            }
            finally
            {
                if (user != null)
                {
                    user.Dispose();
                }
                if (ctx != null)
                {
                    ctx.Dispose();
                }
            }

            return vallidateUserGroup;
        }


        public List<AdUser> GetADUserDetails(string DomianName)
        {
            var ADUsers = new List<AdUser>();
            DirectoryEntry directory = null;
            DirectorySearcher search = null;
            try
            {
                directory = new DirectoryEntry(DomianName);
                search = new DirectorySearcher(directory);
                search.PropertiesToLoad.Add("samaccountname");
                search.PropertiesToLoad.Add("givenName");
                search.PropertiesToLoad.Add("mail");
                search.PropertiesToLoad.Add("AccountExpires");
                search.PropertiesToLoad.Add("sn");
                search.PropertiesToLoad.Add("UserAccountControl");
                search.PropertiesToLoad.Add("cn");
                search.PropertiesToLoad.Add("manager");

                SearchResult result;
                SearchResultCollection resultCollection = search.FindAll();

                if (resultCollection != null)
                {
                    for (int counter = 0; counter < resultCollection.Count; counter++)
                    {
                        result = resultCollection[counter];
                        if (result.Properties.Contains("UserAccountControl") && ((Int32)result.Properties["UserAccountControl"][0] & 512) == 512)
                        {
                            AdUser adUser = new AdUser();
                            adUser.AdStatus = ((Int32)result.Properties["UserAccountControl"][0] & 512) == 512 ? "Active" : "Inactive";
                            adUser.FirstName = PropertyValue(result, "givenName");
                            adUser.LastName = PropertyValue(result, "sn");
                            adUser.UserName = PropertyValue(result, "mail");
                            adUser.AdName = PropertyValue(result, "samaccountname");
                            adUser.Manager = PropertyValue(result, "manager") == " " ? " " : PropertyValue(result, "manager").Split(',')[0].Replace("CN=", "");
                            adUser.FullName = PropertyValue(result, "cn");
                            if (result.Properties.Contains("AccountExpires"))
                            {
                                long date = (long)result.Properties["AccountExpires"][0];
                                adUser.ExpirationDate = LongToDateTime(date);
                            }
                            ADUsers.Add(adUser);
                        }
                    }
                }

            }
            finally
            {
                if (search != null)
                {
                    search.Dispose();
                }
                if (directory != null)
                {
                    directory.Close();
                    directory.Dispose();
                }
            }
            return ADUsers;
        }

        private string PropertyValue(SearchResult result, string p)
        {
            string Value = string.Empty;
            if (result.Properties.Contains(p))
            {
                Value = (String)result.Properties[p][0];
            }
            return Value;
        }

        private DateTime LongToDateTime(long lAccountExpirationDate)
        {
            const long defaultExpireDate = 0x7FFFFFFFFFFFFFFF;

            if (lAccountExpirationDate == 0)
                lAccountExpirationDate = defaultExpireDate;

            if (lAccountExpirationDate == defaultExpireDate)
            {
                return new DateTime(2100, 12, 31);
            }
            return DateTime.FromFileTime(lAccountExpirationDate);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public string RequestToken(string username, string password)
        {
            var token = new Token()
            {
                UserName = username,
                Groups = new[] {"Groups1", "Group2"}
            };
            return CryptoHelper.Encryt(token);
        }
    }
}
