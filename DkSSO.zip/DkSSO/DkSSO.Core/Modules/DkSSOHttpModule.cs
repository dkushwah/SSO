﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Security;
using DkSSO.Core.Security;
using Microsoft.IdentityModel.Claims;

namespace DkSSO.Core.Modules
{
    /// <summary>
    /// 
    /// </summary>
    public class DkSsoHttpModule : IHttpModule
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public void Init(HttpApplication context)
        {
            context.BeginRequest += context_BeginRequest;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void context_BeginRequest(object sender, EventArgs e)
        {

            var authDomain = string.Format("{0}?{1}={2}", AppConfigHelper.SsoProviderAddress, AppConstants.ReturnUrl,
                HttpContext.Current.Request.Url);
            var coockie = HttpContext.Current.Request.Cookies[AppConstants.CoockiName];
            if (coockie != null)
            {
                var tempCookie = HttpContext.Current.Server.UrlDecode(coockie.Value);
                if (tempCookie != null)
                {
                    var tempFat = FormsAuthentication.Decrypt(tempCookie);
                    
                }
                return;
            }
            if (HttpContext.Current.Request.QueryString["token"] == null)
                HttpContext.Current.Response.Redirect(authDomain);
            var token = (string) HttpContext.Current.Request.QueryString["token"];
            if (token != String.Empty)
            {
                token = HttpUtility.UrlDecode(token);
                var tokendata = ValidateToken(token);
                if (tokendata != null)
                {
                    var fat = new FormsAuthenticationTicket(1, tokendata.UserName, DateTime.Now,
                        DateTime.Now.AddHours(1), true, "");
                    //var cookie = new HttpCookie(FormsAuthentication.FormsCookieName)
                    //{
                    //    Value = FormsAuthentication.Encrypt(fat),
                    //    Expires = fat.Expiration
                    //};
                    HttpContext.Current.Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName,
                        FormsAuthentication.Encrypt(fat)));
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        private Token ValidateToken(string token)
        {
            var decrypttoken = CryptoHelper.Decryt<Token>(token);
            return decrypttoken;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        private string GetUserNameFromToken(string token)
        {
            return "Sameerkush704@gmail.com";
        }


        public void Dispose()
        {
        }
    }
}
