﻿using System;
using System.Runtime.Serialization;

namespace DkSSO.Core
{
    [DataContract]
    public class AdUser
    {
        [DataMember]
        public string UserName { get; set; }

        [DataMember]
        public string FirstName { get; set; }

        [DataMember]
        public string LastName { get; set; }

        [DataMember]
        public string AdName { get; set; }

        [DataMember]
        public string AdStatus { get; set; }

        [DataMember]
        public DateTime ExpirationDate { get; set; }

        [DataMember]
        public string FullName { get; set; }

        [DataMember]
        public string Manager { get; set; }
    }
}
