﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DkSSO.Core
{
    /// <summary>
    /// Constant values for application
    /// </summary>
    public class AppConstants
    {
        public const string EncryptionKey = "MAKV2SPBNI99212";
        public const string ReturnUrl = "returnurl";
        public const string RelyingParty = "relyingparty";
        public const string SsoProvider = "SsoProvider";
        public const string LDapServerDomain = "LDapServerDomain";
        public const string LDapServerDirectoryPath = "LDapServerDirectoryPath";
        public const string CoockiName = "SSOAuthenticationCoockie";
    }
}
