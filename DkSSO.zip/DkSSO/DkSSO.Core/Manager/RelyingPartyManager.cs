﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DkSSO.Core.Exception;

namespace DkSSO.Core.Manager
{
    public  class RelyingPartyManager
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public  void ValidateRelyingParty(string name)
        {
            if(name==null)return;
            var uri = new Uri(name);
            string requested = uri.Scheme + Uri.SchemeDelimiter + uri.Host + ":" + uri.Port;

            var rplist = AppConfigHelper.RelyingParties;
            if (rplist==null||!rplist.Any())
            {
                throw new System.Exception("Relying parties not configured");
            }
            var obj = rplist.FirstOrDefault(t => t.Equals(requested, StringComparison.CurrentCultureIgnoreCase));
            if (obj == null)
            {
                throw new RelyingPartyNotFound("Requested Relying party is not registered");
            }
        }
    }
}
