﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DkSSO.Core.Utility
{
    public static class RequestHelper
    {
        public static string GetQString(string queryString, string key)
        {
            var querystringvalues = HttpUtility.ParseQueryString(queryString);
            return querystringvalues.Count > 0 ? querystringvalues.Get(key) : string.Empty;
        }
    }
}
