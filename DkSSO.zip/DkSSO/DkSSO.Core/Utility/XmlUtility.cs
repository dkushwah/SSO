﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace DkSSO.Core.Utility
{
    /// <summary>
    /// 
    /// </summary>
    public static class XmlUtility
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xmlSerializedSamlResponse"></param>
        /// <param name="ReferenceURI"></param>
        /// <param name="signingCert"></param>
        public static void SignXmlDocument(ref XmlDocument xmlSerializedSamlResponse, String ReferenceURI,
            X509Certificate2 signingCert)
        {
            var ns = new XmlNamespaceManager(xmlSerializedSamlResponse.NameTable);
            ns.AddNamespace("saml", "urn:oasis:names:tc:SAML:2.0:assertion");
            if (xmlSerializedSamlResponse.DocumentElement == null) return;
            var xeAssertion =
                xmlSerializedSamlResponse.DocumentElement.SelectSingleNode("saml:Assertion", ns) as XmlElement;
            if (xeAssertion == null) return;
            var signedXml = new SignedXml(xeAssertion) {SigningKey = signingCert.PrivateKey};
            signedXml.SignedInfo.CanonicalizationMethod = SignedXml.XmlDsigExcC14NTransformUrl;
            var reference = new Reference {Uri = ReferenceURI};
            reference.AddTransform(new XmlDsigEnvelopedSignatureTransform());
            reference.AddTransform(new XmlDsigExcC14NTransform());
            signedXml.AddReference(reference);
            signedXml.ComputeSignature();
            var signature = signedXml.GetXml();
            var xeResponse = xmlSerializedSamlResponse.DocumentElement;
            xeResponse.AppendChild(signature);
        }
    }
}
